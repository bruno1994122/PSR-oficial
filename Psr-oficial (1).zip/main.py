import json
import os
import sys
import importlib.util
from PIL import Image, ImageDraw, ImageFont

# Diretórios
LIBRARY_DIR = 'libraries'
PYTHON_LIB_DIR = os.path.join(LIBRARY_DIR, 'python')
CS_LIB_DIR = os.path.join(LIBRARY_DIR, 'csharp')  # Suporte a C# (exemplo)

# Armazena funções e classes criadas no PSR
psr_functions = {}
psr_classes = {}

def screentext(text):
    print(text)

def If(condition):
    return eval(condition)

def set_variable(var_name, value):
    globals()[var_name] = eval(value)

def psr_input(prompt):
    return input(prompt)

def loop(start, end, var_name, code_lines):
    for i in range(int(start), int(end) + 1):
        globals()[var_name] = i
        for line in code_lines:
            process_psr_line(line)

def load_json(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

def create_image(width, height, color, text=None):
    img = Image.new('RGB', (width, height), color)
    if text:
        draw = ImageDraw.Draw(img)
        font = ImageFont.load_default()
        text_width, text_height = draw.textsize(text, font)
        position = ((width - text_width) // 2, (height - text_height) // 2)
        draw.text(position, text, font=font, fill=(255, 255, 255))
    img.save('output_image.png')
    print("Imagem criada e salva como 'output_image.png'")

def import_python_library(library_name):
    """Importa uma biblioteca Python"""
    try:
        lib_path = os.path.join(PYTHON_LIB_DIR, library_name)
        if os.path.exists(lib_path):
            sys.path.append(lib_path)
            spec = importlib.util.spec_from_file_location(library_name, os.path.join(lib_path, '__init__.py'))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            psr_functions[library_name] = module
            print(f"Biblioteca Python '{library_name}' importada com sucesso.")
        else:
            print(f"Biblioteca Python '{library_name}' não encontrada.")
    except Exception as e:
        print(f"Erro ao importar a biblioteca Python: {e}")

def create_library(library_name):
    """Cria uma nova biblioteca"""
    lib_path = os.path.join(PYTHON_LIB_DIR, library_name)
    if not os.path.exists(lib_path):
        os.makedirs(lib_path)
        with open(os.path.join(lib_path, '__init__.py'), 'w') as f:
            f.write("# Biblioteca criada com PSR")
        print(f"Biblioteca '{library_name}' criada com sucesso.")
    else:
        print(f"Biblioteca '{library_name}' já existe.")

def create_class(class_name, methods):
    """Cria uma classe PSR"""
    psr_classes[class_name] = methods
    print(f"Classe '{class_name}' criada com sucesso.")

def define_function(func_name, code_lines):
    """Define uma nova função PSR"""
    def function(*args):
        local_vars = {}
        for line in code_lines:
            exec(line, globals(), local_vars)
        return local_vars.get(func_name, lambda: None)()

    psr_functions[func_name] = function
    print(f"Função '{func_name}' criada com sucesso.")

def process_psr_line(line):
    """Processa cada linha do script PSR"""
    line = line.strip()
    if line.startswith('import '):
        library_name = line.split(' ')[1]
        import_python_library(library_name)
    elif line.startswith('psib bcre '):
        library_name = line.split(' ')[2]
        create_library(library_name)
    elif line.startswith('psib bpub '):
        # Publicar biblioteca (implementação omitida)
        pass
    elif line.startswith('bib.fp('):
        # Implementar lógica para adicionar arquivo Python à biblioteca
        pass
    elif line.startswith('instaled '):
        # Implementar lógica para importar função de biblioteca instalada
        pass
    elif line.startswith('call '):
        # Implementar lógica para chamar uma biblioteca específica
        pass
    elif line.startswith('class '):
        class_part = line[len('class '):]
        class_name, methods_str = class_part.split('{', 1)
        methods_str = methods_str.rstrip('}')
        methods = methods_str.strip().split('\n')
        create_class(class_name.strip(), methods)
    elif line.startswith('cma '):
        func_part = line[len('cma '):]
        func_name, code_str = func_part.split('{', 1)
        code_str = code_str.rstrip('}')
        code_lines = code_str.strip().split('\n')
        define_function(func_name.strip(), code_lines)
    elif line.startswith('screentext '):
        text = line[len('screentext '):]
        screentext(text)
    elif line.startswith('If('):
        condition = line[len('If('):-1]
        If(condition)
    elif '=' in line:
        var_name, value = line.split('=', 1)
        set_variable(var_name.strip(), value.strip())
    elif line.startswith('input('):
        prompt = line[len('input('):-1]
        value = psr_input(prompt)
        set_variable('input', value)
    elif line.startswith('loop('):
        params = line[len('loop('):-1].split(',')
        start, end, var_name = params[0].strip(), params[1].strip(), params[2].strip()
        code_lines = []  # Você deve adicionar a lógica para obter o código das linhas
        loop(start, end, var_name, code_lines)
    elif line.startswith('load_json('):
        file_path = line[len('load_json('):-1]
        data = load_json(file_path)
        print(data)
    elif line.startswith('create_image('):
        params = line[len('create_image('):-1].split(',')
        width, height, color = int(params[0].strip()), int(params[1].strip()), tuple(map(int, params[2].strip().strip('()').split(',')))
        text = params[3].strip() if len(params) > 3 else None
        create_image(width, height, color, text)

def run_psr_script(file_path):
    with open(file_path, 'r') as file:
        lines = [line.strip() for line in file]
        for line in lines:
            process_psr_line(line)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        script_path = sys.argv[1]
        run_psr_script(script_path)
    else:
        print("Por favor, forneça o caminho para o script PSR.")
def import_python_library(library_name):
    """Importa uma biblioteca Python"""
    try:
        lib_path = os.path.join(PYTHON_LIB_DIR, library_name)
        if os.path.exists(lib_path):
            sys.path.append(lib_path)
            spec = importlib.util.spec_from_file_location(library_name, os.path.join(lib_path, '__init__.py'))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            psr_functions[library_name] = module
            print(f"Biblioteca Python '{library_name}' importada com sucesso.")
        else:
            print(f"Biblioteca Python '{library_name}' não encontrada.")
    except Exception as e:
        print(f"Erro ao importar a biblioteca Python: {e}")

def import_csharp_library(library_name):
    """Importa uma biblioteca C#"""
    try:
        # Adicione lógica para carregar e usar a biblioteca C# se possível
        # Placeholder para a integração real com C#
        print(f"Biblioteca C# '{library_name}' importada com sucesso.")
    except Exception as e:
        print(f"Erro ao importar a biblioteca C#: {e}")

def create_library(library_name):
    """Cria uma nova biblioteca"""
    lib_path = os.path.join(PYTHON_LIB_DIR, library_name)
    if not os.path.exists(lib_path):
        os.makedirs(lib_path)
        with open(os.path.join(lib_path, '__init__.py'), 'w') as f:
            f.write("# Biblioteca criada com PSR")
        print(f"Biblioteca '{library_name}' criada com sucesso.")
    else:
        print(f"Biblioteca '{library_name}' já existe.")

def create_class(class_name, methods):
    """Cria uma classe PSR"""
    psr_classes[class_name] = methods
    print(f"Classe '{class_name}' criada com sucesso.")

def define_function(func_name, code_lines):
    """Define uma nova função PSR"""
    def function(*args):
        local_vars = {}
        for line in code_lines:
            exec(line, globals(), local_vars)
        return local_vars.get(func_name, lambda: None)()

    psr_functions[func_name] = function
    print(f"Função '{func_name}' criada com sucesso.")

def process_psr_line(line):
    """Processa cada linha do script PSR"""
    line = line.strip()
    if line.startswith('import '):
        library_name = line.split(' ')[1]
        import_python_library(library_name)
    elif line.startswith('psib bcre '):
        library_name = line.split(' ')[2]
        create_library(library_name)
    elif line.startswith('psib bpub '):
        library_name = line.split(' ')[2]
        # Publicar biblioteca (implementação omitida)
    elif line.startswith('bib.fp('):
        # Implementar lógica para adicionar arquivo Python à biblioteca
        pass
    elif line.startswith('import '):
        library_name = line.split(' ')[1]
        import_python_library(library_name)
    elif line.startswith('instaled '):
        # Implementar lógica para importar função de biblioteca instalada
        pass
    elif line.startswith('call '):
        # Implementar lógica para chamar uma biblioteca específica
        pass
    elif line.startswith('class '):
        class_part = line[len('class '):]
        class_name, methods_str = class_part.split('{', 1)
        methods_str = methods_str.rstrip('}')
        methods = methods_str.strip().split('\n')
        create_class(class_name.strip(), methods)
    elif line.startswith('cma '):
        func_part = line[len('cma '):]
        func_name, code_str = func_part.split('{', 1)
        code_str = code_str.rstrip('}')
        code_lines = code_str.strip().split('\n')
        define_function(func_name.strip(), code_lines)
    elif line.startswith('screentext '):
        text = line[len('screentext '):]
        screentext(text)
    elif line.startswith('If('):
        condition = line[len('If('):-1]
        If(eval(condition))
    elif '=' in line:
        var_name, value = line.split('=', 1)
        set_variable(var_name.strip(), value.strip())
    elif line.startswith('input('):
        prompt = line[len('input('):-1]
        value = psr_input(prompt)
        set_variable('input', value)
    elif line.startswith('loop('):
        params = line[len('loop('):-1].split(',')
        start, end, var_name = params[0].strip(), params[1].strip(), params[2].strip()
        code_lines = []  # Você deve adicionar a lógica para obter o código das linhas
        loop(start, end, var_name, code_lines)
    elif line.startswith('load_json('):
        file_path = line[len('load_json('):-1]
        data = load_json(file_path)
        print(data)
    elif line.startswith('create_image('):
        params = line[len('create_image('):-1].split(',')
        width, height, color = int(params[0].strip()), int(params[1].strip()), tuple(map(int, params[2].strip().strip('()').split(',')))
        text = params[3].strip() if len(params) > 3 else None
        create_image(width, height, color, text)

def run_psr_script(file_path):
    with open(file_path, 'r') as file:
        lines = [line.strip() for line in file]
        for line in lines:
            process_psr_line(line)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        script_path = sys.argv[1]
        run_psr_script("maip.psr")
    else:
        print("Por favor, forneça o caminho para o script PSR.")