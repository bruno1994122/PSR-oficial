#!/bin/bash

# Verifica se o diretório de bibliotecas existe
LIBRARY_DIR="libraries"
if [ ! -d "$LIBRARY_DIR" ]; then
    mkdir "$LIBRARY_DIR"
fi

# Cria uma nova biblioteca
create_library() {
    local lib_name=$1
    local lib_path="$LIBRARY_DIR/$lib_name"

    if [ -d "$lib_path" ]; then
        echo "Biblioteca '$lib_name' já existe."
        exit 1
    else
        mkdir "$lib_path"
        touch "$lib_path/__init__.py"
        echo "Biblioteca '$lib_name' criada com sucesso."
    fi
}

# Verifica os argumentos e executa a função
if [ "$#" -ne 2 ] || [ "$1" != "bcre" ]; then
    echo "Uso: $0 bcre <nome_da_biblioteca>"
    exit 1
fi

create_library "$2"