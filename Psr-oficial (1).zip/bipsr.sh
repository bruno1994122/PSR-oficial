#!/bin/bash

# Executa o script Python do servidor com o comando apropriado
python3 server.py "$@"