    import os
    import shutil
    import sys

    LIBRARY_DIR = 'libraries'

    def install_library(library_name, source_path):
        """Instala uma biblioteca no servidor"""
        dest_path = os.path.join(LIBRARY_DIR, library_name)

        if not os.path.exists(dest_path):
            os.makedirs(dest_path)

        try:
            shutil.copy(source_path, dest_path)
            print(f"Biblioteca '{library_name}' instalada com sucesso.")
        except Exception as e:
            print(f"Erro ao instalar a biblioteca: {e}")

    def create_library(library_name):
        """Cria uma nova biblioteca no servidor"""
        lib_path = os.path.join(LIBRARY_DIR, library_name)

        if not os.path.exists(lib_path):
            os.makedirs(lib_path)
            with open(os.path.join(lib_path, '__init__.py'), 'w') as f:
                f.write('# Biblioteca criada\n')
            print(f"Biblioteca '{library_name}' criada com sucesso.")
        else:
            print(f"Biblioteca '{library_name}' já existe.")

    if __name__ == "__main__":
        if len(sys.argv) < 2:
            print("Uso: python server.py <comando> [opções]")
            sys.exit(1)

        command = sys.argv[1]

        if command == 'install':
            if len(sys.argv) != 4:
                print("Uso: python server.py install <nome_da_biblioteca> <caminho_para_o_arquivo>")
                sys.exit(1)
            install_library(sys.argv[2], sys.argv[3])

        elif command == 'create':
            if len(sys.argv) != 3:
                print("Uso: python server.py create <nome_da_biblioteca>")
                sys.exit(1)
            create_library(sys.argv[2])

        else:
            print(f"Comando '{command}' não reconhecido.")
            sys.exit(1)