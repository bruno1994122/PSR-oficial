import os
import shutil
import sys

LIBRARY_DIR = 'libraries'

def install_library(library_name, source_path):
    """Instala uma biblioteca no servidor"""
    dest_path = os.path.join(LIBRARY_DIR, library_name)
    
    # Verifica se o diretório de destino existe, caso contrário, cria-o
    if not os.path.exists(dest_path):
        os.makedirs(dest_path)
    
    # Copia o arquivo da biblioteca para o diretório de destino
    try:
        shutil.copy(source_path, dest_path)
        print(f"Biblioteca '{library_name}' instalada com sucesso.")
    except Exception as e:
        print(f"Erro ao instalar a biblioteca: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python install_library.py <nome_da_biblioteca> <caminho_para_o_arquivo>")
        sys.exit(1)
    
    library_name = sys.argv[1]
    source_path = sys.argv[2]
    
    install_library(library_name, source_path)